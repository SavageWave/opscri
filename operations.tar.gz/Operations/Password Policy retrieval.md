
```
crackmapexec smb 172.16.5.5 -u avazquez -p Password123 --pass-pol
```

```
ldapsearch -h 172.16.5.5 -x -b "DC=INLANEFREIGHT,DC=LOCAL" -s sub "*" | grep -m 1 -B 10 pwdHistoryLength
```

```
rpcclient -U "" -N 172.16.5.5


querydominfo
```

```
enum4linux -P 172.16.5.5 -oA ilfreight
```



FROM WINDOWS 

```
net use \\DC01\ipc$ "" /u:""
```
```
net use \\DC01\ipc$ "" /u:guest
```
```
 net use \\DC01\ipc$ "password" /u:guest
```


```
net accounts
```

