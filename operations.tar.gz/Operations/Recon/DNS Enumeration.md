website that holds SSL Certificates!!
[[CRT.sh]]

```
curl -s https://crt.sh/\?q\=targeturl.com\&output\=json | jq . | grep name | cut -d":" -f2 | grep -v "CN=" | cut -d'"' -f2 | awk '{gsub(/\\n/,"\n");}1;' | sort -u
```

```
dig -t AXFR inlanefreight.htb @10.129.154.120

```


```
dig any inlanefreight.com
```

Continue to do dig for zone transfers for the hosts/servers you were given from the first zone transfer.

```
dnsenum --dnsserver 10.129.14.128 --enum -p 0 -s 0 -o subdomains.txt -f /opt/useful/SecLists/Discovery/DNS/subdomains-top1million-110000.txt inlanefreight.htb
```

```
fierce --domain domainname.com
```


scrapes for subdomains
```
./subfinder -d inlanefreight.com -v
```


ettercap or bettercap can do DNS cache poisoning
edit /etc/ettercap/etter.dns

q