**Default Passwords**

https://cirt.net/passwords
https://default-password.info/
https://datarecovery.com/rd/default-passwords/

**Sorting and removing duplicates**

```
sort combined_list.txt | uniq -u > cleaned_combined_list.txt
```

**Creating a wordlist you can use Crunch**


**Common password generator passed off of a users info**

git clone https://github.com/Mebus/cupp.git


**Hashes**
```
hashid
```


```
hash-identifier
```

Password generator  only capital letters and 0-9 
```
#!/bin/bash

for x in {{A..Z},{0..9}}{{A..Z},{0..9}}{{A..Z},{0..9}}{{A..Z},{0..9}}
    do echo $x;
done
```