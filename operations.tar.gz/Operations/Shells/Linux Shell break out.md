```
sudo apt-get update -o APT::Update::Pre-Invoke::=/bin/sh
```
