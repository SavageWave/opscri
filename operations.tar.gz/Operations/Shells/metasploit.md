```
sessions -i 1
```


sudo systemctl start postgresql
sudo msfdb init

msf6 > workspace -h

Usage:
    workspace                  List workspaces
    workspace -v               List workspaces verbosely
    workspace [name]           Switch workspace
    workspace -a [name] ...    Add workspace(s)
    workspace -d [name] ...    Delete workspace(s)
    workspace -D               Delete all workspaces
    workspace -r     Rename workspace
    workspace -h               Show this help information

IMPORTING NMAP scans
```
db_import Target.xml
```

```
search type:exploit platform:windows cve:2021 rank:excellent microsoft
```

```
search ms17_010
```

```
show enconders
```

msf-virustotal -k <API key> -f TeamViewerInstall.exe
