General Nmap mail query
```
sudo nmap -Pn -sV -sC -p25,143,110,465,587,993,995 10.129.14.128
```


```
sudo nmap 10.129.202.20 -sV -p110,143,993,995 -sC
```

```
curl -k 'imaps://10.129.42.195' --user robin:robin
```

```
openssl s_client -connect 10.129.142.25:imaps
openssl s_client -connect 10.129.136.26:pop3s
```

Process for logging into an IMAP server and retrieving an email
```
A1 LOGIN "ROBIN" "ROBIN"
A1 LIST "" *
A1 SELECT "DEV.DEPARTMENT.INT"
A3 FETCH 1 (BODY.PEEK[])

```


IMAP Commands
```
Command	Description
1 LOGIN username password	User's login.
1 LIST "" *	Lists all directories.
1 CREATE "INBOX"	Creates a mailbox with a specified name.
1 DELETE "INBOX"	Deletes a mailbox.
1 RENAME "ToRead" "Important"	Renames a mailbox.
1 LSUB "" *	Returns a subset of names from the set of names that the User has declared as being active or subscribed.
1 SELECT INBOX	Selects a mailbox so that messages in the mailbox can be accessed.
1 UNSELECT INBOX	Exits the selected mailbox.
1 FETCH <ID> all	Retrieves data associated with a message in the mailbox.
1 CLOSE	Removes all messages with the Deleted flag set.
1 LOGOUT	Closes the connection with the IMAP server.
```



POP3 Commands
Command	Description
USER username	Identifies the user.   we can use the command USER followed by the username, and if the server responds OK. This means that the user exists on the server.
PASS password	Authentication of the user using its password.
STAT	Requests the number of saved emails from the server.
LIST	Requests from the server the number and size of all emails.
RETR id	Requests the server to deliver the requested email by ID.
DELE id	Requests the server to delete the requested email by ID.
CAPA	Requests the server to display the server capabilities.
RSET	Requests the server to reset the transmitted information.
QUIT	Closes the connection with the POP3 server.

retrieve email
```
telnet STMIP 143
11 login "marlin@inlanefreight.htb" "poohbear"
12 select "INBOX"
13 FETCH 1 BODY[]
```

Password guessing against pop3 

```
hydra -L users.txt -p 'Company01!' -f 10.10.110.20 pop3
```

