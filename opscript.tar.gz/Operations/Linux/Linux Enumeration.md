

```
ls /etc/*-release


cat /etc/os-release

uname -a

lsb_release -a

hostnamectl

```

```
find /mnt/Finance/ -name *cred*

grep -rn /mnt/Finance/ -ie cred
```

```
hostname
```


```
cat /etc/passwd
cat /etc/group
cat /etc/shadow
```

```
ls -lh /var/mail
```

```
ls -lh /usr/bin
ls -lh /usr/sbin
```

```
rpm -qa
```

```
dpkg -l
```

```
who
```

```
id
```

```
last
```

```
ip a s 
```

```
ifconfig -a
```

```
cat /etc/resolve.conf
```

```
netstat -punta
```

```
ps axjf
```



