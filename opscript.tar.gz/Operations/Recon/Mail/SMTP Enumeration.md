TCP/25	SMTP Unencrypted
TCP/143	IMAP4 Unencrypted
TCP/110	POP3 Unencrypted
TCP/465	SMTP Encrypted
TCP/587	SMTP Encrypted/STARTTLS
TCP/993	IMAP4 Encrypted
TCP/995	POP3 Encrypted

General Nmap mail query
```
sudo nmap -Pn -sV -sC -p25,143,110,465,587,993,995 10.129.14.128
```

https://serversmtp.com/smtp-error/
SMTP Response codesVRF

```
sudo nmap 10.129.42.195 -p25 --script smtp-open-relay -v
```

-w to add time for response, this was critical
```
smtp-user-enum -M VRFY -U footprinting-wordlist.txt -t 10.129.42.195 -w 20  
```

verify if users exist,  have to have a domain selected
```
smtp-user-enum -M RCPT -U /usr/share/seclists/Usernames/xato-net-10-million-usernames.txt -D inlanefreight.htb -t 10.129.203.7
```


```
telnet 10.129.14.128 25
```
```
ehlo domainname
```


SMTP Commands

AUTH PLAIN	AUTH is a service extension used to authenticate the client.
HELO	The client logs in with its computer name and thus starts the session.
MAIL FROM	The client names the email sender.
RCPT TO	The client names the email recipient.RCPT TO identifies the recipient of the email message. This command can be repeated multiple times for a given message to deliver a single message to multiple recipients.
DATA	The client initiates the transmission of the email.
RSET	The client aborts the initiated transmission but keeps the connection between client and server.
VRFY	The client checks if a mailbox is available for message transfer.  VRFY this command instructs the receiving SMTP server to check the validity of a particular email username. The server will respond, indicating if the user exists or not. This feature can be disabled.
EXPN	The client also checks if a mailbox is available for messaging with this command.  EXPN is similar to VRFY, except that when used with a distribution list, it will list all users on that list. This can be a bigger problem than the VRFY command since sites often have an alias such as "all."
NOOP	The client requests a response from the server to prevent disconnection due to time-out.
QUIT	The client terminates the session.

```
msfconsole
use auxiliary/scanner/smtp/smtp_enum
set RHOSTS
run

```



Open relay attack
```
 swaks --from notifications@inlanefreight.com --to employees@inlanefreight.com --header 'Subject: Company Notification' --body 'Hi All, we want to hear from you! Please complete the following survey. http://mycustomphishinglink.com/' --server 10.10.11.213
 ```


Password guessing
```
hydra -l marlin@inlanefreight.htb -P /usr/share/wordlists/rockyou.txt smtp://10.129.72.61 -f
```