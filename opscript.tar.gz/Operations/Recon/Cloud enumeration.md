google search

```
intext:company info inurl:amazonaws.com
```

```
intext:company info inurl:blob.core.windows.net

```

