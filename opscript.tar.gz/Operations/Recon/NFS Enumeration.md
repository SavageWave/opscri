```
sudo nmap 10.129.14.128 -p111,2049 -sV -sC


sudo nmap --script nfs* 10.129.202.5 -sV -p111,2049
```

```
showmount -e 10.129.14.128


```

```
mkdir target-NFS
sudo mount -t nfs 10.129.14.128:/ ./target-NFS/ -o nolock
cd target-NFS
tree .
sudo su

sudo umount ./target-NFS
```