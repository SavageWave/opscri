```
dirsearch -u http://url 
```

```
gobuster dir -u http://10.129.203.7 -w /usr/share/wordlists/dirbuster/directory-list.2.3-medium.txt -b 301
```


```
gobuster dir -u http://10.10.10.121/ -w /usr/share/dirb/wordlists/common.txt
```


curl -IL https://www.inlanefreight.com

whatweb 10.101.101.10

```

ffuf -recursion -recursion-depth 5 -u http://faculty.academy.htb:42068/FUZZ -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -e .php7  
```


```
 ffuf -recursion -recursion-depth 1 -u http://192.168.10.10/FUZZ -w /opt/useful/SecLists/Discovery/Web-Content/raft-small-directories-lowercase.txt

```

-recursion: Activates the recursive scan.
-recursion-depth: Specifies the maximum depth to scan.
-u: Our target URL, and FUZZ will be the injection point.
-w: Path to our wordlist.


Additional crawling discovery used to generate new crawling wordlists

```
cewl -m5 --lowercase -w wordlist.txt http://192.168.10.10
```

Then run with additional wordlists
```
ffuf -w ./folders.txt:FOLDERS,./wordlist.txt:WORDLIST,./extensions.txt:EXTENSIONS -u http://192.168.10.10/FOLDERS/WORDLISTEXTENSIONS
```


https://www.wappalyzer.com/lookup/i.imgur.com/


VHOST DISCOVERY
```
ffuf -w /usr/share/dnsrecon/subdomains-top1mil.txt:FUZZ -u http://94.237.49.121:48647/ -H 'Host: FUZZ.academy.htb' | egrep -v 986

```


PARAMETER DISCOVERY for GET requests
```

ffuf -w /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u http://94.237.49.121:48647/admin/admin.php?FUZZ=key -H 'Host: admin.academy.htb' | egrep -v 798
```


PARAMETER DISCOVERY for POST requests
```
ffuf -w /opt/useful/SecLists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u http://admin.academy.htb:PORT/admin/admin.php -X POST -d 'FUZZ=key' -H 'Content-Type: application/x-www-form-urlencoded' -fs xxx
```

testing parmeters with post curl
```
curl http://faculty.academy.htb:42068/courses/linux-security.php7 -X POST -d 'user=info' -H 'Content-Type: application/x-www-form-urlencoded'
```

identifying the value of parameters  created ids.txt with numbers to identify the key
```
ffuf -w ids.txt:FUZZ -u http://.faculty.academy.htb:42068/courses/linux-security.php7 -X POST -d 'user=FUZZ' -H 'Content-Type: application/x-www-form-urlencoded' 
```