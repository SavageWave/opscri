

GREAT WEBSITE FOR SUBDOMAIN ENUMERATION
[[crt.sh]]


Virtual hosts
 
 cd /opt/useful/SecLists/Discovery/DNS/namelist.txt

```
cat ./vhosts | while read vhost;do echo "\n********\nFUZZING: ${vhost}\n********";curl -s -I http://192.168.10.10 -H "HOST: ${vhost}.randomtarget.com" | grep "Content-Length: ";done
```


ffuf can automatie virtual hosts discovery

```
ffuf -w ./vhosts -u http://192.168.10.10 -H "HOST: FUZZ.randomtarget.com" -fs 612
```
-w: Path to our wordlist
-u: URL we want to fuzz
-H "HOST: FUZZ.randomtarget.com": This is the HOST Header, and the word FUZZ will be used as the fuzzing point.
-fs 612: Filter responses with a size of 612, default response size in this case.



c
curl -s http://192.168.10.10 -H "Host: dev-admin.randomtarget.com"



