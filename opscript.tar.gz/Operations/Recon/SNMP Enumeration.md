sn
```
snmpwalk -v 2c -c public 10.129.144.25
```

snmpwalk -v 2c -c private  10.129.42.253

onesixtyone -c dict.txt 10.129.42.254

```
onesixtyone -c /opt/useful/SecLists/Discovery/SNMP/snmp.txt 10.129.14.128
```

```
 braa <community string>@<IP>:.1.3.6.*   # Syntax
braa public@10.129.14.128:.1.3.6.*
```